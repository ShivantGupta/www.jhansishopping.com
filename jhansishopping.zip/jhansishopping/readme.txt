1) Open PHPmyAdmin
2) Import db.sql file from this folder
3) Enjoy.